from selenium import webdriver
from PIL import Image
import time
from selenium.webdriver.edge.service import Service
from selenium.webdriver.common.by import By

# Configuração do WebDriver
# driver_path = 'CAMINHO_PARA_O_SEU_WEBDRIVER'
url = url que deseja capturar a imagem
screenshot_path = '.\Imagens'  # Use r-string ou duplique as barras invertidas

# Inicialize o WebDriver
service = Service(service_args=['--verbose'])  # Use service_args em vez de verbose
driver = webdriver.Edge(service = service)
driver.get(url)

# Aguarde o carregamento da página (ajuste o tempo conforme necessário)
# time.sleep(10)

# Loop para recarregar a página e capturar screenshots repetidamente
# Defina o contador
i = 1

# Loop para recarregar a página e capturar screenshots repetidamente
while True:
    # preciso que seja clicado no botão de fechar de um modal que aparece na tela
    time.sleep(2)
    driver.find_element(By.XPATH, '//*[@id="myModal"]/div/div/div[1]/button').click()

    # Aguarde o carregamento da página após o refresh (ajuste conforme necessário)
    time.sleep(2)

    # Tire um screenshot da página inteira
    driver.save_screenshot('full_screenshot.png')

    element = driver.find_element(By.XPATH, '//*[@id="image"]')
    location = element.location
    size = element.size

    # x = location['x']
    # y = location['y']
    # width = size['width']
    # height = size['height']
    
    # image = Image.open('full_screenshot.png')
    # cropped_image = image.crop((x, y, x + 360, y + 150))

    # # Salve a imagem na pasta 'imagen' com um número sequencial
    # screenshot_path = r'imagens\imagem' + str(i) + '.png'

    # Coordenadas originais e dimensões do elemento
    x = location['x']
    y = location['y']
    width = size['width']
    height = size['height']

    # Ajustar para incluir mais espaço à esquerda e em cima
    x_ajustado = x + 100   # Espaço esquerda
    y_ajustado = y + 100   # Espaço acima

    # Ajustar largura e altura para incluir a área adicional
    largura_ajustada = width + 40   # Espaço à direita
    altura_ajustada = height + 6  # Espaço abaixo

    # Corte da imagem
    image = Image.open('full_screenshot.png')
    cropped_image = image.crop((x_ajustado, y_ajustado, x_ajustado + largura_ajustada, y_ajustado + altura_ajustada))

    screenshot_path = r'imagens\imagem' + str(i) + '.png'

    cropped_image.save(screenshot_path)

    # Incremente o contador
    i += 1

    # Aguarde um tempo antes de recarregar a página novamente (ajuste conforme necessário)
    time.sleep(1)
    driver.refresh()

# Não esqueça de fechar o driver no final
driver.quit()